import {useEffect} from "react";

const RegistrarCitas = () => {

    useEffect(() => {

    },);

    return (
        <div>
            <h1>Registrar Citas</h1>
        </div>
    );

}
export default RegistrarCitas;