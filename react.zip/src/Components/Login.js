import React, {useEffect, useState} from 'react';
import axios from 'axios';
import {useNavigate,Link} from "react-router-dom";
import {isAuthenticated} from "./Config/auth";

const Login = () => {
    const navigate = useNavigate();
    useEffect(() => {
        if (isAuthenticated()) {
            navigate('/');
        }
    }, );

    const [formData, setFormData] = useState({
        username: '',
        password: '',
    });

    const [errorMessage, setErrorMessage] = useState(''); // Estado para mostrar el mensaje de error

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post('http://localhost:8080/login', formData);
            if (response.status === 200) {
                localStorage.setItem('rol', response.data.Roles[0].authority);
                localStorage.setItem('token', response.data.token);
                navigate('/')

            }
        } catch (error) {
            // Mostrar un mensaje de error
            setErrorMessage('Usuario Incorrecto');
            localStorage.removeItem('token');

            // Ocultar el mensaje después de 4 segundos
            setTimeout(() => {
                setErrorMessage('');
            }, 10000);
        }
    };

    return (
        <div className="container">
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <h2 className="text-center mb-4">Login</h2>
                    {errorMessage && (
                        <div className="alert alert-danger" role="alert">
                            {errorMessage}
                        </div>
                    )}
                    <form onSubmit={handleLogin}>
                        <div className="mb-3">
                            <label htmlFor="username" className="form-label">Username</label>
                            <input
                                type="text"
                                name="username"
                                value={formData.username}
                                onChange={handleInputChange}
                                className="form-control"
                                id="username"
                                required
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="password" className="form-label">Password</label>
                            <input
                                type="password"
                                name="password"
                                value={formData.password}
                                onChange={handleInputChange}
                                className="form-control"
                                id="password"
                                required
                            />
                        </div>
                        <button type="submit" className="btn btn-primary">Login</button>
                        <Link to="/regUsuarios" className="btn btn-link">O Registrarse</Link>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Login;
