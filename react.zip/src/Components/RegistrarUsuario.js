import axios from "axios";
import {useState} from "react";


const RegistrarUsuario = () => {

    const [formData, setFormData] = useState({
        email: '',
        username: '',
        password: '',
        phone: '',
        roles: ['USER']
    });
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };
    const registrarse = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8080/api/createUser', formData);
            if (response.status === 200) {
                window.alert("Usuario Registrado")
            }

        } catch (e) {
            console.log(e);
        }
    }
    return (
        <div className="container">
            <h2 className="mt-5 mb-4">Registro de Usuario</h2>

            <form onSubmit={registrarse}>
                <div className="form-group">
                    <label htmlFor="email">Correo Electrónico:</label>
                    <input type="email"
                           name={"email"}
                           value={formData.email}
                           onChange={handleInputChange}
                           className="form-control"
                           id="email"
                           placeholder="Ingrese su email"
                           required/>
                </div>

                <div className="form-group">
                    <label htmlFor="username">Nombre de Usuario:</label>
                    <input type="text"
                            name={"username"}
                           value={formData.username}
                           onChange={handleInputChange}
                           className="form-control"
                           id="username"
                           placeholder="Ingrese un nombre de usuario"
                           required/>
                </div>

                <div className="form-group">
                    <label htmlFor="password">Contraseña:</label>
                    <input type="password"
                            name={"password"}
                           value={formData.password}
                           onChange={handleInputChange}
                           className="form-control"
                           id="password"
                           placeholder="Ingrese su contraseña"
                           required/>
                </div>

                <div className="form-group">
                    <label htmlFor="phone">Número de Teléfono:</label>
                    <input type="tel"
                            name={"phone"}
                           value={formData.phone}
                           onChange={handleInputChange}
                           className="form-control"
                           id="phone"
                           placeholder="Ingrese su número de teléfono"/>
                </div>

                <button type="submit" class="btn btn-primary" >Registrarse</button>
            </form>
        </div>
    );
}
export default RegistrarUsuario;