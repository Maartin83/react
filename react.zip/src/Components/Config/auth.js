// auth.js

export function isAuthenticated() {
    const storedToken = localStorage.getItem('token');

    if (storedToken) {
        const decodedToken = parseJWT(storedToken);
        const currentTime = Date.now() / 1000;

        if (decodedToken.exp && decodedToken.exp < currentTime) {
            // El token ha expirado
            localStorage.removeItem('token');
            return false;
        } else {
            // El token es válido
            return true;
        }
    }
    // No se encontró un token
    return false;
}

export function cerrarSesion() {
    localStorage.removeItem('token');
    localStorage.removeItem('rol');
    window.location.href = '/login';
}
export function obtenerusername() {
    try {
        const storedToken = localStorage.getItem('token');
        const decodedToken = parseJWT(storedToken);
        return decodedToken.sub;
    }catch (e) {
        return null;
    }

}
//is role admin
export function isRoleAdmin() {
    const storedRole = localStorage.getItem('rol');
    if (storedRole) {
        return storedRole === 'ROLE_ADMIN' && isAuthenticated();
    }
    return false;
}
export function isRoleUser() {
    const storedRole = localStorage.getItem('rol');
    if (storedRole) {
        return storedRole === 'ROLE_USER' && isAuthenticated();
    }
    return false;
}
//funcion para verificar si el usuario tiene rol de INVITED

export function parseJWT(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace('-', '+').replace('_', '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}
