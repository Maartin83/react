import {useEffect} from "react";
import {isRoleAdmin} from "../Config/auth";
import React from "react";

const GestionAdmin = () => {
    useEffect(() => {
        if (!isRoleAdmin()){
            window.location.href = '/error403';
        }
    }, []);
    return (
        <div>
            <h1>GestionAdmin</h1>
        </div>
    )
}
export default GestionAdmin;