import './App.css';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from "./Components/Login";
import Home from "./Components/Home";
import RegistrarCitas from "./Components/RegistrarCitas";
import Error404 from "./Components/Config/Error404";
import Error403 from "./Components/Config/Error403";
import GestionAdmin from "./Components/admin/GestionAdmin";
import RegistrarUsuario from "./Components/RegistrarUsuario";

function App() {
  return (
      <Router>
          <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/" element={<Home />} />
              <Route path="/regCitas" element={<RegistrarCitas />} />
              <Route path="/regUsuarios" element={<RegistrarUsuario />} />
              <Route path="*" element={<Error404/>} />
              <Route path="/error403" element={<Error403/>} />
              {/* ADMIN */}
                <Route path="/admin" element={<GestionAdmin />} />
          </Routes>
      </Router>
  );
}

export default App;
